const CORE='samed-core-v19',UNITS='samed-units-v19';
const ASSETS=['./','./index.html','./app.js','./styles.css','./dashboard-v13.css','./manifest.webmanifest','./icon-192.png','./icon-512.png','./offline.html','./contact.html'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CORE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>![CORE,UNITS].includes(key)).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET')return;event.respondWith(caches.match(event.request).then(hit=>hit||fetch(event.request).then(response=>{const copy=response.clone();caches.open(CORE).then(cache=>cache.put(event.request,copy));return response}).catch(()=>caches.match('./offline.html'))))});
